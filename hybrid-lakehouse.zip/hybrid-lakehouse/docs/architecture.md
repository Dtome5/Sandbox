# Architecture and delivery semantics

## Chosen stack

Redpanda provides the Kafka wire protocol with a smaller local footprint. Spark 3.5.5 and
Iceberg 1.7.2 provide microbatch processing and atomic commits per table. MinIO supplies local
S3 storage. Trino is the common SQL plane for dbt and Superset. Prefect coordinates finite
batch pulls and Gold builds; the long-lived stream is supervised by Docker independently.
Great Expectations validates compact aggregate results, avoiding collecting the lake into RAM.

The pinned REST fixture implements the Iceberg REST protocol used by newer clients. Test the
exact server/client combination when upgrading. Local SQLite metadata is persisted in its own
named volume. It is neither a clustered catalog nor a replacement for a managed catalog.

## Bronze and recovery

Each Kafka microbatch runs these operations in order:

1. Append immutable JSON files with topic, partition, offset, timestamps, and base64 key/value.
2. MERGE the Bronze offset index by SHA-256 of `topic:partition:offset`.
3. Validate the contract. MERGE malformed records into the quarantine table.
4. Publish rejected records to the DLQ with the same stable source ID as key.
5. MERGE accepted events into Silver by event ID.
6. Return successfully, allowing Spark to commit its checkpoint.

There is **no atomic transaction across all tables, object files, and Kafka**. A crash between
steps can expose partially processed data until retry completes. Raw files can be duplicated
on replay; the queryable offset index and Silver tables deduplicate. DLQ Kafka messages can
repeat, so consumers must deduplicate the stable key. A malformed payload cannot break JSON
decoding for the batch. Infrastructure, storage, or programming failures abort and retry the
batch rather than being mistaken for bad business data.

First committed event ID wins. A producer that reuses the same ID with changed content will
not update Silver. Enforce unique event IDs upstream; add a versioned correction stream or
conflict quarantine before supporting corrections. Kafka topic recreation also requires a
new source namespace/checkpoint because offsets alone identify records only within one topic
lifetime. A single stream deployment owns a checkpoint and its Silver writer.

`startingOffsets=earliest` applies on first start. Subsequent starts resume from checkpoints.
`failOnDataLoss=true` fails visibly if offsets have expired; it cannot recover deleted broker
records. Local broker retention is seven days, replication is one, and MinIO is single-node.
This is not a zero-loss SLA. RPO depends on durable producer acknowledgments, broker quorum,
object storage availability, checkpoint retention, and disaster recovery procedures.

Provider raw responses are archived before normalized Kafka publication. A crash between
those steps leaves an archive for a controlled backfill. Repeated quote timestamps generate
the same provider ID, preventing duplicate quotes after retries. Unchanged provider timestamps
are deliberately treated as the same quote.

## Time and models

Source event timestamps are UTC. Processing time is stored separately as `ingested_at`.
There is no watermark dropping late packets; Silver keeps valid late events. Incremental facts
use processing-time lookback rather than event time, and full marts recompute rolling windows.
The one-hour ingestion overlap assumes one authoritative stream writer and no independent
backfill preserving artificially old ingestion timestamps. Use `dbt build --full-refresh`
after such backfills. Multiple events at one timestamp use event ID as a deterministic order
for quote windows; these are observations, not daily financial bars.

Dimensions use stable hashed natural keys. A device is an inverter, an instrument is a symbol
in the configured universe, and date is shared across facts. Adding multi-currency or multiple
venues requires extending instrument identity and the wire contract. Unseen dimensions are
derived from accepted events so joins do not silently drop them. Financial and IoT tables can
be joined by reporting time but no causal relationship is assumed.

For ML, use event time **and** ingestion availability time when building point-in-time features.
A complete hour's average is only available after the hour closes; financial quotes must be
chosen as of the prediction timestamp. Do not randomly split adjacent time-series rows or
use later quotes while training on earlier inverter observations.

## Scaling and Iceberg

The Spark UDF uses the same Pydantic contracts as ingestion and tests. This is a correctness
baseline with Python serialization overhead; it has no measured throughput claim. Before
high-volume deployment, benchmark it against native Spark expressions or vectorized parsing
and keep the contract fixtures as equivalence tests. Scale Kafka partitions and Spark workers
together, tune batch offsets, and measure commit latency. Whole-table MERGE scans and full
mart rebuilds will need pruning/incremental redesign as retained history grows.

Partition evolution changes future file partition specs; existing files remain readable.
Sort compaction rewrites existing data to the configured sort order. Choose daily/hourly
granularity from measured volume and file sizes; device buckets can overpartition small data.
Do not claim Z-ordering for this configuration. Benchmark identical snapshots/query predicates,
hardware, cache conditions, and concurrency. Record query stats, result equality, repeated
latencies, and median improvement `(before - after) / before * 100`.

Snapshots are not automatically expired. Introduce retention only after accounting for replay,
audit, long-running readers, and recovery objectives. Deleting data files directly can corrupt
Iceberg tables; use catalog procedures and a reviewed orphan-file retention policy.

