# Operational runbook

## First checks

```bash
docker compose ps -a
docker compose logs --tail 100 init stream catalog trino
docker compose exec trino trino --execute 'SELECT count(*) FROM lake.bronze.dead_letters'
docker compose exec trino trino --execute 'SELECT topic, reason, count(*) FROM lake.bronze.dead_letters GROUP BY 1, 2'
```

Stream logs expose batch progress and offsets. The Spark master UI shows worker/executor
status. Observe Kafka lag, batch duration, ingestion delay, DLQ rate, commit failures, object
growth, and Prefect/dbt failures. This repository does not include a Prometheus deployment or
production alert routing; wire those metrics to the target monitoring system.

| Symptom | Action |
| --- | --- |
| No Silver tables | Inspect `init`; verify catalog `/v1/config`, bucket, connector JARs, and credentials. |
| Bronze grows, Silver does not | Inspect quarantine reasons and stream errors; schema drift is deliberately rejected. |
| Stream restarts repeatedly | Fix the underlying error while keeping the checkpoint; do not delete state to hide it. |
| Offset out of range | Preserve evidence. Recover from retained raw objects into a separate audited backfill, or restore broker data. |
| GX fails | Inspect `governance/quality/`; Gold refresh is blocked. Repair inputs or explicitly version a changed contract. |
| dbt fails | Inspect Prefect logs and `governance/dbt/`; rerun after fixing the cause. |
| Superset bootstrap fails | Verify Gold exists, then restart Superset. |
| Small files accumulate | Run sort compaction; review batch size and partition design before increasing worker count. |

## Replay and backfill

Normal restart uses `docker compose restart stream`. Keep all named volumes; never share a
checkpoint across simultaneous writers. Kafka replay deduplicates Bronze source offsets and
Silver IDs. Republishing archived payloads to source topics creates new source offsets but
retains event IDs, so Silver stays unique. Keep the original archive and a backfill manifest.
Do not blindly replay malformed DLQ records: repair/version the payload first and document
whether the correction should preserve identity or be a new event.

The included cluster smoke test requires **fresh volumes** and checks exact fixture counts.
It intentionally fails on pre-existing data. Use a separate checkout/Compose project to run
it; do not remove a developer's lake to make a test pass.

## Catalog and object recovery

Back up catalog metadata and object storage together. S3 object versions alone do not replace
the catalog. Verify a restore in an isolated environment before enabling writers. Preserve
checkpoint objects and their versions. Local MinIO bucket versioning helps accidental object
replacement; it is not independent disaster recovery or an immutability lock.

Iceberg commits are atomic per table, but a dbt build replaces tables in sequence. A failed
build can leave a mixture of old and new Gold models. Production consumers requiring a
consistent multi-table release should build into a release schema, validate it, and switch
views/catalog routing as a controlled promotion. This reference deployment does not implement
that promotion mechanism.

## Shutdown

`docker compose --profile bi --profile orchestration down` preserves data volumes. Let Kafka
producers flush and Spark finish the current batch before maintenance. Removing volumes is
destructive and is never required for normal restart.

