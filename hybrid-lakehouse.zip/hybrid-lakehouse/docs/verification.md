# Verification evidence

The implementation was checked on 17 November 2026. These results describe this build,
not a deployed cloud service or a production throughput certification.

| Check | Result |
| --- | --- |
| Offline DuckDB pipeline with real Great Expectations checks | Passed; 304 raw records, 240 telemetry, 60 quotes, four quarantined records |
| Offline replay | Passed; no additional Silver rows and two immutable captures |
| Payload contracts and malformed binary preservation | Passed |
| Mocked provider HTTP retry and stable quote identity | Passed |
| Actual local Spark Python UDF execution | Passed |
| Actual Iceberg 1.7.2 DDL, insert-only MERGE replay, partition evolution | Passed using Spark 3.5.5 and a local Hadoop catalog |
| Checked-in JSON schemas | Match the runtime Pydantic contracts |
| Combined local test suite | 40 passed, including Spark and Iceberg execution |
| Ruff lint and format checks | Passed |
| dbt parse | Passed with dbt Core 1.9.4 / dbt Trino 1.9.3 |
| Compose configuration validation | Passed |
| Terraform format/init/validate | Passed with Terraform 1.11.4 / AWS provider 5.99.1 |
| Full Kafka → MinIO → REST catalog → Spark → Trino → dbt | Not completed in this environment |
| Prefect scheduled deployment and Superset browser flow | Configured; not exercised end to end |
| AWS apply / production deployment | Not run |
| High-frequency throughput / query percentage improvement | Not measured |

The complete Docker test was constrained by an 8 GB filesystem and the selected Docker
daemon's VFS storage driver, which copies image layers. The first MinIO source build filled
the available filesystem; its temporary build cache was removed. An attempt with a smaller
builder hit a download error inside the build. The source URL and archive checksum were
verified separately, and the Dockerfile now uses a checksum-pinned BuildKit ADD. The final
source-build revision and the full Compose stack have not been built here.

Run `scripts/smoke_cluster.py` in a fresh, adequately sized Docker environment before treating
the multi-service deployment as release-tested. The included GitHub Actions cluster job runs
this path and `dbt build`, including the dbt unit test. Merely including this workflow is not
evidence that a remote CI run has occurred. No GitHub repository was created or published.

Sample outputs are included in `examples/verified-demo/`; test XML is in `examples/verification/`.
They were produced by the offline and local Spark/Iceberg checks, not by the complete cluster.

