# Cloud foundation and production release work

The code is production-oriented and locally reproducible. Production readiness depends on
the target workload, infrastructure, access controls, and recovery tests. No cloud resources
were provisioned as part of creating this project.

## Terraform scope

The AWS module provisions S3 with public-access blocking, TLS-only policy, versioning and
KMS encryption; a rotating KMS key; an immutable/scanned ECR repository; Glue databases;
a scoped EMR execution role; and a bounded EMR Serverless Spark application for batch jobs.
It deliberately creates no shared credentials, public broker, or automatic deployment.

```bash
cd infra/terraform
cp terraform.tfvars.example terraform.tfvars
# Set a globally unique bucket name and configure AWS authentication externally.
terraform init
terraform plan -out=review.tfplan
# Apply only after reviewing cost, IAM, data retention, and the concrete plan.
```

Configure an encrypted remote state backend with locking for team use. Bucket destruction is
guarded and force-delete is disabled. Do not add lifecycle expiry to checkpoint or Iceberg
metadata paths. Use workload roles and short-lived identity federation for CI deployment;
the included CI is validation-only. Separate ingestion, quality, modeling, and BI permissions
for a shared service rather than extending the local root MinIO credentials.

EMR Serverless is a batch foundation here. The repository does not submit jobs to it or attach
streaming networking. To use Glue rather than REST, adapt Spark catalog configuration to
`org.apache.iceberg.aws.glue.GlueCatalog`, use the prefixed Glue database names from Terraform,
remove local S3 endpoints, use AWS's credential chain, and configure Trino's Glue catalog.
The current stream builder intentionally targets local REST/MinIO; changing environment
variables alone does not perform this migration. EMR's bundled Spark/Iceberg versions must be
tested independently of the local 3.5.5/1.7.2 connector bundle.

## Before a production release

1. Deploy a multi-AZ Kafka/Redpanda quorum with replication factor at least three, minimum
   in-sync replicas, producer `acks=all`, TLS, authenticated clients, and topic ACLs.
2. Replace MinIO's single-node demo with durable object storage and a highly available
   catalog. Back up catalog and state, and prove restoration against stated RPO/RTO.
3. Deploy Spark with appropriate executors, network policy, resource limits, graceful
   supervision, immutable images, and persistent checkpoints. Establish exclusive writer
   ownership and a controlled correction/backfill workflow.
4. Add TLS/authentication to Trino, Superset, Prefect and catalog. Move secrets to a managed
   secret store, configure BI roles and data access, and use a supported catalog authorization
   layer. Only local loopback ports are protected by this Compose file.
5. Load test realistic rates, burst sizes, device cardinality, Kafka lag, table size, and
   downstream concurrency. Python validation, MERGE scans and full mart rebuilds are known
   scaling limits to measure. Tune partitions and file sizes from evidence.
6. Exercise broker failures, object-store faults, driver termination during each sink write,
   failed quality gates, late events, schema upgrades, and restore. The small fixture replay
   check is a starting point, not a chaos or durability certification.
7. Add monitoring/alerts and retention ownership. Set explicit SLOs for freshness, recovery,
   acceptable quarantine rate, and serving availability. Promote coherent Gold releases if
   readers require consistency across multiple models.
8. Review dependency/image support and vulnerabilities, pin image digests for releases,
   and use a protected deployment environment gated on successful CI and a reviewed plan.

Finances are quote analytics, not trading signals or execution infrastructure. Validate market
licensing, timestamp meaning, exchange/currency identity, and sample bias for the intended use.

