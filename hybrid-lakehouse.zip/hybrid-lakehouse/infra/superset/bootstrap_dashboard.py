"""Idempotent local dashboard bootstrap. Run after the first dbt build."""

import json

from superset import db
from superset.app import create_app
from superset.connectors.sqla.models import SqlaTable
from superset.models.core import Database
from superset.models.dashboard import Dashboard
from superset.models.slice import Slice

app = create_app()
with app.app_context():
    database = db.session.query(Database).filter_by(database_name="Lakehouse").one_or_none()
    if database is None:
        database = Database(
            database_name="Lakehouse",
            sqlalchemy_uri="trino://bi@trino:8080/lake/gold",
            expose_in_sqllab=True,
        )
        db.session.add(database)
        db.session.flush()
    charts = []
    for table_name, title, time_column, metric, group in [
        ("mart_power_hourly", "Power by inverter", "hour", "avg_power_kw", "device_id"),
        (
            "mart_market_trends",
            "Market moving average",
            "event_time",
            "moving_avg_20_quotes",
            "symbol",
        ),
    ]:
        table = (
            db.session.query(SqlaTable)
            .filter_by(database_id=database.id, schema="gold", table_name=table_name)
            .one_or_none()
        )
        if table is None:
            table = SqlaTable(table_name=table_name, schema="gold", database=database)
            db.session.add(table)
            db.session.flush()
        table.fetch_metadata()
        chart = db.session.query(Slice).filter_by(slice_name=title).one_or_none()
        if chart is None:
            chart = Slice(
                slice_name=title,
                viz_type="echarts_timeseries_line",
                datasource_id=table.id,
                datasource_type="table",
            )
            db.session.add(chart)
        chart.params = json.dumps(
            {
                "datasource": f"{table.id}__table",
                "viz_type": "echarts_timeseries_line",
                "x_axis": time_column,
                "granularity_sqla": time_column,
                "time_range": "No filter",
                "time_grain_sqla": "PT1M",
                "groupby": [group],
                "metrics": [
                    {
                        "expressionType": "SIMPLE",
                        "column": {"column_name": metric},
                        "aggregate": "AVG",
                        "label": metric,
                    }
                ],
                "row_limit": 10000,
                "show_legend": True,
            }
        )
        charts.append(chart)
    dashboard = db.session.query(Dashboard).filter_by(slug="hybrid-intelligence").one_or_none()
    if dashboard is None:
        dashboard = Dashboard(
            dashboard_title="Hybrid IoT & Market Intelligence",
            slug="hybrid-intelligence",
            published=True,
        )
        db.session.add(dashboard)
    dashboard.slices = charts
    db.session.flush()
    positions = {
        "DASHBOARD_VERSION_KEY": "v2",
        "ROOT_ID": {"id": "ROOT_ID", "type": "ROOT", "children": ["GRID_ID"]},
        "GRID_ID": {"id": "GRID_ID", "type": "GRID", "children": ["ROW-1"], "parents": ["ROOT_ID"]},
        "ROW-1": {
            "id": "ROW-1",
            "type": "ROW",
            "parents": ["ROOT_ID", "GRID_ID"],
            "children": [f"CHART-{c.id}" for c in charts],
            "meta": {"background": "BACKGROUND_TRANSPARENT"},
        },
    }
    for chart in charts:
        positions[f"CHART-{chart.id}"] = {
            "id": f"CHART-{chart.id}",
            "type": "CHART",
            "children": [],
            "parents": ["ROOT_ID", "GRID_ID", "ROW-1"],
            "meta": {"chartId": chart.id, "width": 6, "height": 60, "sliceName": chart.slice_name},
        }
    dashboard.position_json = json.dumps(positions)
    db.session.commit()
