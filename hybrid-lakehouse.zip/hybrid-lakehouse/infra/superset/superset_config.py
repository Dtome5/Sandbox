import os
from urllib.parse import quote_plus

SECRET_KEY = os.environ["SUPERSET_SECRET_KEY"]
SQLALCHEMY_DATABASE_URI = (
    "postgresql+psycopg2://superset:"
    + quote_plus(os.environ["POSTGRES_PASSWORD"])
    + "@postgres:5432/superset"
)
WTF_CSRF_ENABLED = True
TALISMAN_ENABLED = False  # Local HTTP only; terminate TLS for shared deployments.
FEATURE_FLAGS = {"ENABLE_TEMPLATE_PROCESSING": False}
