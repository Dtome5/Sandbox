#!/usr/bin/env bash
set -euo pipefail
superset db upgrade
superset fab create-admin --username admin --firstname Lakehouse --lastname Admin \
  --email admin@example.invalid --password "$SUPERSET_ADMIN_PASSWORD" || \
  python -c 'from superset.app import create_app; from superset import security_manager; app=create_app(); ctx=app.app_context(); ctx.push(); assert security_manager.find_user(username="admin"), "admin creation failed"'
superset init
python /app/bootstrap_dashboard.py
exec gunicorn --bind 0.0.0.0:8088 --workers 2 --timeout 120 'superset.app:create_app()'

