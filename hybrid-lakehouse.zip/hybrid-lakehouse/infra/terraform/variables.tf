variable "region" {
  type    = string
  default = "us-east-1"
}
variable "project" {
  type    = string
  default = "hybrid-lakehouse"
  validation {
    condition     = can(regex("^[a-z][a-z0-9-]{2,30}$", var.project))
    error_message = "Use a lowercase project name, 3 to 31 characters."
  }
}
variable "bucket_name" {
  description = "A globally unique bucket name in your AWS account."
  type        = string
}

