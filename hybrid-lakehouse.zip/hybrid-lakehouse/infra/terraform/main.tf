terraform {
  required_version = ">= 1.10, < 2.0"
  required_providers {
    aws = { source = "hashicorp/aws", version = "~> 5.99.0" }
  }
  # Supply an encrypted remote backend with state locking during terraform init.
}

provider "aws" {
  region = var.region
  default_tags { tags = { Project = var.project, ManagedBy = "Terraform" } }
}

data "aws_caller_identity" "current" {}

resource "aws_kms_key" "lake" {
  description             = "Hybrid lakehouse object encryption"
  deletion_window_in_days = 30
  enable_key_rotation     = true
}

resource "aws_kms_alias" "lake" {
  name          = "alias/${var.project}-lake"
  target_key_id = aws_kms_key.lake.key_id
}

resource "aws_s3_bucket" "lake" {
  bucket        = var.bucket_name
  force_destroy = false
  lifecycle { prevent_destroy = true }
}

resource "aws_s3_bucket_public_access_block" "lake" {
  bucket                  = aws_s3_bucket.lake.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_versioning" "lake" {
  bucket = aws_s3_bucket.lake.id
  versioning_configuration { status = "Enabled" }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "lake" {
  bucket = aws_s3_bucket.lake.id
  rule {
    bucket_key_enabled = true
    apply_server_side_encryption_by_default {
      sse_algorithm     = "aws:kms"
      kms_master_key_id = aws_kms_key.lake.arn
    }
  }
}

data "aws_iam_policy_document" "tls" {
  statement {
    sid       = "DenyInsecureTransport"
    effect    = "Deny"
    actions   = ["s3:*"]
    resources = [aws_s3_bucket.lake.arn, "${aws_s3_bucket.lake.arn}/*"]
    principals {
      type        = "*"
      identifiers = ["*"]
    }
    condition {
      test     = "Bool"
      variable = "aws:SecureTransport"
      values   = ["false"]
    }
  }
}

resource "aws_s3_bucket_policy" "lake" {
  bucket = aws_s3_bucket.lake.id
  policy = data.aws_iam_policy_document.tls.json
}

resource "aws_ecr_repository" "pipeline" {
  name                 = "${var.project}-pipeline"
  image_tag_mutability = "IMMUTABLE"
  image_scanning_configuration { scan_on_push = true }
  encryption_configuration {
    encryption_type = "KMS"
    kms_key         = aws_kms_key.lake.arn
  }
}

resource "aws_glue_catalog_database" "layers" {
  for_each = toset(["bronze", "silver", "gold"])
  name     = "${replace(var.project, "-", "_")}_${each.value}"
}

data "aws_iam_policy_document" "emr_trust" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["emr-serverless.amazonaws.com"]
    }
    condition {
      test     = "StringEquals"
      variable = "aws:SourceAccount"
      values   = [data.aws_caller_identity.current.account_id]
    }
  }
}

resource "aws_iam_role" "spark" {
  name               = "${var.project}-spark"
  assume_role_policy = data.aws_iam_policy_document.emr_trust.json
}

data "aws_iam_policy_document" "spark" {
  statement {
    actions   = ["s3:ListBucket", "s3:GetBucketLocation"]
    resources = [aws_s3_bucket.lake.arn]
  }
  statement {
    actions   = ["s3:GetObject", "s3:PutObject", "s3:DeleteObject", "s3:AbortMultipartUpload"]
    resources = [for prefix in ["bronze", "warehouse", "checkpoints", "governance", "artifacts"] : "${aws_s3_bucket.lake.arn}/${prefix}/*"]
  }
  statement {
    actions   = ["kms:Decrypt", "kms:Encrypt", "kms:GenerateDataKey", "kms:DescribeKey"]
    resources = [aws_kms_key.lake.arn]
  }
  statement {
    actions = ["glue:GetDatabase", "glue:GetDatabases", "glue:GetTable", "glue:GetTables",
    "glue:CreateTable", "glue:UpdateTable", "glue:DeleteTable"]
    resources = concat(
      ["arn:aws:glue:${var.region}:${data.aws_caller_identity.current.account_id}:catalog"],
      [for database in aws_glue_catalog_database.layers : database.arn],
      [for database in aws_glue_catalog_database.layers : "arn:aws:glue:${var.region}:${data.aws_caller_identity.current.account_id}:table/${database.name}/*"]
    )
  }
}

resource "aws_iam_role_policy" "spark" {
  role   = aws_iam_role.spark.id
  policy = data.aws_iam_policy_document.spark.json
}

resource "aws_emrserverless_application" "spark" {
  name          = "${var.project}-batch"
  release_label = "emr-7.5.0"
  type          = "SPARK"
  maximum_capacity {
    cpu    = "16 vCPU"
    memory = "64 GB"
    disk   = "200 GB"
  }
  auto_start_configuration { enabled = true }
  auto_stop_configuration {
    enabled              = true
    idle_timeout_minutes = 10
  }
}

