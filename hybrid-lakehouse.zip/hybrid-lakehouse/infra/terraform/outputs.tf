output "lake_bucket" { value = aws_s3_bucket.lake.id }
output "kms_key_arn" { value = aws_kms_key.lake.arn }
output "container_repository" { value = aws_ecr_repository.pipeline.repository_url }
output "batch_application_id" { value = aws_emrserverless_application.spark.id }
output "batch_execution_role_arn" { value = aws_iam_role.spark.arn }
output "glue_databases" { value = { for name, db in aws_glue_catalog_database.layers : name => db.name } }

