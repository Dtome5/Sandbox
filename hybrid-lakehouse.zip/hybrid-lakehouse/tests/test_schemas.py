import json
from pathlib import Path

from lakehouse.contracts import TOPIC_MODELS


def test_checked_in_wire_schemas_match_validators():
    root = Path(__file__).resolve().parents[1]
    for topic, model in TOPIC_MODELS.items():
        assert json.loads((root / "schemas" / f"{topic}.schema.json").read_text()) == (
            model.model_json_schema()
        )
