"""Optional local Iceberg execution, independent of Docker/S3.

Set ICEBERG_RUNTIME_JAR to the pinned Spark 3.5 / Iceberg 1.7.2 runtime JAR.
"""

import os
import sys
from datetime import datetime

import pytest
from pyspark.sql import SparkSession

from lakehouse.processing.stream import create_tables, merge_insert


@pytest.mark.integration
def test_iceberg_ddl_merge_replay_and_partition_evolution(tmp_path):
    jar = os.getenv("ICEBERG_RUNTIME_JAR")
    if not jar:
        pytest.skip("Set ICEBERG_RUNTIME_JAR for local Iceberg execution")
    os.environ["PYSPARK_PYTHON"] = sys.executable
    spark = (
        SparkSession.builder.master("local[1]")
        .appName("iceberg-replay-test")
        .config("spark.jars", jar)
        .config("spark.ui.enabled", "false")
        .config("spark.sql.shuffle.partitions", "1")
        .config("spark.sql.session.timeZone", "UTC")
        .config(
            "spark.sql.extensions",
            "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions",
        )
        .config("spark.sql.catalog.lake", "org.apache.iceberg.spark.SparkCatalog")
        .config("spark.sql.catalog.lake.type", "hadoop")
        .config("spark.sql.catalog.lake.warehouse", str(tmp_path / "warehouse"))
        .getOrCreate()
    )
    try:
        create_tables(spark)
        frame = spark.createDataFrame(
            [
                (
                    "e1",
                    datetime(2026, 1, 5, 9),
                    "inverter-001",
                    230.0,
                    2.5,
                    30.0,
                    "source-1",
                    datetime(2026, 1, 5, 10),
                )
            ],
            "event_id STRING, event_time TIMESTAMP, device_id STRING, voltage DOUBLE, "
            "power_kw DOUBLE, temperature_c DOUBLE, source_id STRING, ingested_at TIMESTAMP",
        )
        merge_insert(spark, frame, "lake.silver.telemetry", "event_id")
        merge_insert(spark, frame, "lake.silver.telemetry", "event_id")
        assert spark.table("lake.silver.telemetry").count() == 1
        assert spark.table("lake.silver.telemetry").first().power_kw == 2.5
        spark.sql(
            "ALTER TABLE lake.silver.telemetry REPLACE PARTITION FIELD days(event_time) "
            "WITH hours(event_time)"
        )
        assert spark.table("lake.silver.telemetry").count() == 1
    finally:
        spark.stop()
