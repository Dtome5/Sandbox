import asyncio

import httpx
import pytest

from lakehouse.ingestion.finance import fetch_quote, normalize_quote


def test_finance_retry_and_stable_provider_id(monkeypatch):
    calls = []

    def respond(request):
        calls.append(request)
        assert request.headers["X-Finnhub-Token"] == "test-token"
        assert "token" not in request.url.params
        return httpx.Response(503 if len(calls) == 1 else 200, json={"c": 230.5, "t": 1767603600})

    async def no_delay(seconds):
        pass

    monkeypatch.setattr(asyncio, "sleep", no_delay)

    async def run():
        async with httpx.AsyncClient(
            base_url="https://finnhub.io", transport=httpx.MockTransport(respond)
        ) as client:
            return await fetch_quote(client, "AAPL", "test-token")

    raw = asyncio.run(run())
    assert len(calls) == 2
    assert normalize_quote("AAPL", raw).event_id == normalize_quote("AAPL", raw).event_id
    assert normalize_quote("AAPL", raw).volume is None


def test_invalid_provider_quote_is_rejected():
    with pytest.raises(ValueError):
        normalize_quote("AAPL", {"c": 0, "t": 0})
