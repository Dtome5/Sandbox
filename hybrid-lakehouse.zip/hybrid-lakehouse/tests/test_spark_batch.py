"""Local Spark execution validates binary conversion and the shared Python UDF."""

import json
import os
import sys

import pytest
from pyspark.sql import SparkSession
from pyspark.sql import functions as F

from lakehouse.contracts import validate_payload
from lakehouse.fixtures import sample_events


@pytest.fixture(scope="module")
def spark():
    os.environ["PYSPARK_PYTHON"] = sys.executable
    session = (
        SparkSession.builder.master("local[1]")
        .appName("contract-tests")
        .config("spark.pyspark.python", sys.executable)
        .config("spark.ui.enabled", "false")
        .getOrCreate()
    )
    yield session
    session.stop()


def test_binary_contract_udf_preserves_malformed_bytes(spark):
    topic, valid = next(sample_events(1))
    frame = spark.createDataFrame(
        [(topic, bytearray(valid)), (topic, bytearray(b"\xff\xfe"))], "topic STRING, value BINARY"
    )
    validate = F.udf(validate_payload, "canonical STRING, reason STRING")
    rows = frame.select(
        F.base64("value").alias("raw"), validate("topic", "value").alias("result")
    ).collect()
    assert json.loads(rows[0].result.canonical)["device_id"] == "inverter-001"
    assert rows[1].raw == "//4="
    assert rows[1].result.reason is not None
