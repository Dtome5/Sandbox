import base64
import json
from datetime import UTC, datetime, timedelta

import pytest

from lakehouse.contracts import validate_payload
from lakehouse.fixtures import bad_events, sample_events


@pytest.mark.parametrize("topic,payload", list(sample_events(12)))
def test_valid_fixtures_roundtrip(topic, payload):
    canonical, reason = validate_payload(topic, payload)
    assert reason is None
    assert json.loads(canonical)["event_id"] == json.loads(payload)["event_id"]


@pytest.mark.parametrize("topic,payload", list(bad_events()))
def test_bad_bytes_are_quarantined_and_recoverable(topic, payload):
    canonical, reason = validate_payload(topic, payload)
    assert canonical is None
    assert json.loads(reason)
    assert base64.b64decode(base64.b64encode(payload)) == payload


@pytest.mark.parametrize(
    "changes",
    [
        {"voltage": None},
        {"voltage": 301},
        {"power_kw": -1},
        {"temperature_c": 121},
        {"new_field": 10},
        {"schema_version": 2},
        {"schema_version": True},
        {"event_time": "2026-01-05T09:00:00"},
        {"event_time": 0},
        {"event_time": (datetime.now(UTC) + timedelta(hours=1)).isoformat()},
        {"voltage": True},
        {"power_kw": float("nan")},
    ],
)
def test_schema_drift_ranges_and_timestamp_errors(changes):
    topic, raw = next(sample_events(1))
    payload = json.loads(raw) | changes
    canonical, reason = validate_payload(topic, json.dumps(payload).encode())
    assert canonical is None
    assert reason is not None


def test_unknown_topic_is_rejected():
    assert validate_payload("other", b"{}")[0] is None
