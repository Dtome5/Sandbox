import duckdb
import pandas as pd
import pytest

from lakehouse.demo import run_demo
from lakehouse.quality import check_frame, quality_metrics_query


def test_pipeline_preserves_bad_bytes_and_replay_is_idempotent(tmp_path):
    first = run_demo(tmp_path)
    second = run_demo(tmp_path)
    assert (
        first
        == second
        == {
            "input_records": 304,
            "silver_telemetry": 240,
            "silver_market": 60,
            "quarantined": 4,
            "quality_passed": True,
        }
    )
    assert len(list((tmp_path / "bronze").glob("*.jsonl"))) == 2
    conn = duckdb.connect(str(tmp_path / "lakehouse.duckdb"))
    assert conn.sql("SELECT sum(readings) FROM gold.power_hourly").fetchone()[0] == 240
    assert conn.sql("SELECT count(*) FROM gold.market_trends").fetchone()[0] == 60
    assert conn.sql("SELECT count(*) FROM quarantine WHERE raw_base64 = '//4='").fetchone()[0] == 1
    conn.close()


def test_quality_gate_blocks_duplicate_ids():
    bad = pd.DataFrame(
        [
            {"event_id": "same", "event_time": "2026-01-05", "symbol": "AAPL", "price": 10},
            {"event_id": "same", "event_time": "2026-01-05", "symbol": "AAPL", "price": 11},
        ]
    )
    with pytest.raises(ValueError, match="gate failed"):
        check_frame(bad, "market")


def test_null_price_fails_quality_even_when_range_comparison_is_null():
    bad = pd.DataFrame(
        [{"event_id": "e1", "event_time": "2026-01-05", "symbol": "AAPL", "price": None}]
    )
    with pytest.raises(ValueError, match="gate failed"):
        check_frame(bad, "market")
    conn = duckdb.connect(":memory:")
    conn.execute("CREATE SCHEMA silver")
    conn.register("bad", bad)
    conn.execute("CREATE TABLE silver.market AS SELECT * FROM bad")
    # Local DuckDB has the same aggregate/null semantics; replace the catalog only.
    metrics = conn.execute(quality_metrics_query("market").replace("lake.silver", "silver"))
    row = dict(zip([c[0] for c in metrics.description], metrics.fetchone(), strict=True))
    assert row["range_failures"] == 0
    assert row["null_fields"] == 1
    conn.close()
