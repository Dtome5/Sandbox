import json
import random
from datetime import UTC, datetime, timedelta
from uuid import NAMESPACE_URL, uuid5


def sample_events(count: int = 240, seed: int = 7):
    """Repeatable sample with old source times and stable IDs; no network needed."""
    rng = random.Random(seed)
    start = datetime(2026, 1, 5, 9, tzinfo=UTC)
    for i in range(count):
        at = (start + timedelta(seconds=i * 15)).isoformat()
        yield (
            "telemetry.v1",
            json.dumps(
                {
                    "schema_version": 1,
                    "event_id": str(uuid5(NAMESPACE_URL, f"iot:{seed}:{i}")),
                    "event_time": at,
                    "device_id": f"inverter-{i % 3 + 1:03}",
                    "voltage": round(rng.uniform(218, 242), 2),
                    "power_kw": round(rng.uniform(2, 8), 3),
                    "temperature_c": round(rng.uniform(24, 48), 2),
                }
            ).encode(),
        )
        if i % 4 == 0:
            yield (
                "market.quotes.v1",
                json.dumps(
                    {
                        "schema_version": 1,
                        "event_id": str(uuid5(NAMESPACE_URL, f"quote:{seed}:{i}")),
                        "event_time": at,
                        "symbol": ["AAPL", "MSFT", "NEE"][i // 4 % 3],
                        "price": round(100 + rng.uniform(-5, 5), 2),
                        "volume": 1000 + i,
                    }
                ).encode(),
            )


def bad_events():
    yield "telemetry.v1", b'{"broken":'
    yield "telemetry.v1", b"\xff\xfe"
    yield (
        "telemetry.v1",
        json.dumps(
            {
                "schema_version": 1,
                "event_id": "bad-voltage",
                "event_time": "2026-01-05T09:00:00Z",
                "device_id": "inverter-001",
                "voltage": 999,
                "power_kw": 2,
                "temperature_c": 30,
            }
        ).encode(),
    )
    yield (
        "market.quotes.v1",
        json.dumps(
            {
                "schema_version": 2,
                "event_id": "drift",
                "event_time": "2026-01-05T09:00:00Z",
                "symbol": "AAPL",
                "price": -1,
                "unexpected_field": True,
            }
        ).encode(),
    )
