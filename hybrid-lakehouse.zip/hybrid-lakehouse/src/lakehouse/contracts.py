"""Versioned wire contracts shared by the local demo and Spark workers."""

import json
from datetime import UTC, datetime, timedelta
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator


class Envelope(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)
    schema_version: Literal[1]
    event_id: str = Field(min_length=1, max_length=128, strict=True)
    event_time: datetime

    @field_validator("schema_version", mode="before")
    @classmethod
    def integer_version(cls, value):
        if type(value) is not int:
            raise ValueError("schema_version must be an integer")
        return value

    @field_validator("event_time", mode="before")
    @classmethod
    def explicit_timestamp(cls, value):
        if not isinstance(value, str | datetime):
            raise ValueError("ISO timestamp required")
        return value

    @field_validator("event_time")
    @classmethod
    def utc_timestamp(cls, value):
        if value.tzinfo is None:
            raise ValueError("timezone is required")
        if value > datetime.now(UTC) + timedelta(minutes=5):
            raise ValueError("timestamp is more than five minutes in the future")
        return value.astimezone(UTC)


class Telemetry(Envelope):
    device_id: str = Field(pattern=r"^[A-Za-z0-9_-]{1,64}$", strict=True)
    voltage: float = Field(ge=0, le=300, strict=True)
    power_kw: float = Field(ge=0, le=1000, strict=True)
    temperature_c: float = Field(ge=-50, le=120, strict=True)


class Quote(Envelope):
    symbol: str = Field(pattern=r"^[A-Z][A-Z0-9.\-]{0,14}$", strict=True)
    price: float = Field(gt=0, le=1_000_000, strict=True)
    volume: int | None = Field(default=None, ge=0, strict=True)


TOPIC_MODELS = {"telemetry.v1": Telemetry, "market.quotes.v1": Quote}


def validate_payload(topic: str, payload: bytes | str) -> tuple[str | None, str | None]:
    """Return canonical JSON or a bounded, structured quarantine reason.

    Raw bytes remain in Bronze. Error messages deliberately omit input values.
    """
    model = TOPIC_MODELS.get(topic)
    if model is None:
        return None, json.dumps({"code": "unknown_topic"})
    try:
        event = model.model_validate_json(payload)
        return event.model_dump_json(), None
    except ValidationError as error:
        reasons = [
            {"field": ".".join(map(str, e["loc"])), "code": e["type"]}
            for e in error.errors(include_url=False, include_input=False)
        ]
        return None, json.dumps(reasons, separators=(",", ":"))[:4096]
