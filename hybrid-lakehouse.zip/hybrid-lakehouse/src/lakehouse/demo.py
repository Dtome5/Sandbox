"""A small, offline contract/replay demonstration. Does not emulate a cluster."""

import base64
import hashlib
import json
from datetime import UTC, datetime
from pathlib import Path

import duckdb

from lakehouse.contracts import validate_payload
from lakehouse.fixtures import bad_events, sample_events
from lakehouse.quality import check_frame


def run_demo(directory: Path) -> dict:
    directory.mkdir(parents=True, exist_ok=True)
    (directory / "bronze").mkdir(exist_ok=True)
    conn = duckdb.connect(str(directory / "lakehouse.duckdb"))
    conn.execute("CREATE SCHEMA IF NOT EXISTS silver")
    conn.execute("CREATE SCHEMA IF NOT EXISTS gold")
    conn.execute("""CREATE TABLE IF NOT EXISTS silver.telemetry (
        event_id VARCHAR PRIMARY KEY, event_time TIMESTAMPTZ, device_id VARCHAR,
        voltage DOUBLE, power_kw DOUBLE, temperature_c DOUBLE)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS silver.market (
        event_id VARCHAR PRIMARY KEY, event_time TIMESTAMPTZ, symbol VARCHAR,
        price DOUBLE, volume BIGINT)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS quarantine (
        source_id VARCHAR PRIMARY KEY, topic VARCHAR, raw_base64 VARCHAR, reason VARCHAR)""")
    events = list(sample_events()) + list(bad_events())
    archive = (
        directory / "bronze" / f"capture-{datetime.now(UTC).strftime('%Y%m%dT%H%M%S%f')}.jsonl"
    )
    with archive.open("x") as raw:
        for offset, (topic, payload) in enumerate(events):
            source_id = hashlib.sha256(f"{topic}:{offset}".encode()).hexdigest()
            encoded = base64.b64encode(payload).decode()
            raw.write(json.dumps({"topic": topic, "offset": offset, "raw_base64": encoded}) + "\n")
            canonical, error = validate_payload(topic, payload)
            if error:
                conn.execute(
                    "INSERT OR IGNORE INTO quarantine VALUES (?, ?, ?, ?)",
                    [source_id, topic, encoded, error],
                )
                continue
            event = json.loads(canonical)
            if topic == "telemetry.v1":
                values = [
                    event[k]
                    for k in [
                        "event_id",
                        "event_time",
                        "device_id",
                        "voltage",
                        "power_kw",
                        "temperature_c",
                    ]
                ]
                conn.execute(
                    "INSERT OR IGNORE INTO silver.telemetry VALUES (?, ?, ?, ?, ?, ?)", values
                )
            else:
                values = [event[k] for k in ["event_id", "event_time", "symbol", "price", "volume"]]
                conn.execute("INSERT OR IGNORE INTO silver.market VALUES (?, ?, ?, ?, ?)", values)
    reports = {
        kind: check_frame(conn.sql(f"SELECT * FROM silver.{kind}").df(), kind)
        for kind in ["telemetry", "market"]
    }
    conn.execute("""CREATE OR REPLACE TABLE gold.power_hourly AS
        SELECT device_id, date_trunc('hour', event_time) AS hour,
               count(*) AS readings, avg(power_kw) AS avg_power_kw, avg(voltage) AS avg_voltage
        FROM silver.telemetry GROUP BY 1, 2""")
    conn.execute("""CREATE OR REPLACE TABLE gold.market_trends AS
        WITH prices AS (SELECT *, lag(price) OVER
            (PARTITION BY symbol ORDER BY event_time, event_id) AS previous_price
            FROM silver.market)
        SELECT *, avg(price) OVER w AS moving_avg_20_quotes,
            stddev_samp(ln(price / previous_price)) OVER w AS log_return_volatility_20_quotes
        FROM prices WINDOW w AS (PARTITION BY symbol ORDER BY event_time, event_id
            ROWS BETWEEN 19 PRECEDING AND CURRENT ROW)""")
    for table in ["power_hourly", "market_trends"]:
        destination = str((directory / f"{table}.parquet").resolve()).replace("'", "''")
        conn.execute(f"COPY gold.{table} TO '{destination}' (FORMAT PARQUET)")
    summary = {
        "input_records": len(events),
        "silver_telemetry": conn.sql("SELECT count(*) FROM silver.telemetry").fetchone()[0],
        "silver_market": conn.sql("SELECT count(*) FROM silver.market").fetchone()[0],
        "quarantined": conn.sql("SELECT count(*) FROM quarantine").fetchone()[0],
        "quality_passed": all(r["success"] for r in reports.values()),
    }
    (directory / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    (directory / "quality.json").write_text(json.dumps(reports, indent=2, default=str) + "\n")
    conn.close()
    return summary
