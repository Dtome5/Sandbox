"""Kafka microbatches with ordered durable writes and replay-safe Iceberg MERGEs."""

import os
import sys

from pyspark.sql import SparkSession, Window
from pyspark.sql import functions as F
from pyspark.sql import types as T

from lakehouse.config import Settings
from lakehouse.contracts import validate_payload

PACKAGES = ",".join(
    [
        "org.apache.iceberg:iceberg-spark-runtime-3.5_2.12:1.7.2",
        "org.apache.iceberg:iceberg-aws-bundle:1.7.2",
        "org.apache.spark:spark-sql-kafka-0-10_2.12:3.5.5",
        "org.apache.hadoop:hadoop-aws:3.3.4",
    ]
)


def spark_session():
    os.environ.setdefault("PYSPARK_PYTHON", sys.executable)
    cfg = Settings.from_env()
    builder = (
        SparkSession.builder.appName("hybrid-lakehouse")
        .master(os.getenv("SPARK_MASTER", "local[2]"))
        .config("spark.sql.session.timeZone", "UTC")
        .config("spark.sql.shuffle.partitions", os.getenv("SHUFFLE_PARTITIONS", "4"))
        .config(
            "spark.sql.extensions",
            "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions",
        )
        .config("spark.sql.catalog.lake", "org.apache.iceberg.spark.SparkCatalog")
        .config("spark.sql.catalog.lake.type", "rest")
        .config("spark.sql.catalog.lake.uri", cfg.catalog_uri)
        .config("spark.sql.catalog.lake.warehouse", f"s3://{cfg.bucket}/warehouse")
        .config("spark.sql.catalog.lake.io-impl", "org.apache.iceberg.aws.s3.S3FileIO")
        .config("spark.sql.catalog.lake.s3.endpoint", cfg.s3_endpoint)
        .config("spark.sql.catalog.lake.s3.path-style-access", "true")
        .config("spark.hadoop.fs.s3a.endpoint", cfg.s3_endpoint)
        .config("spark.hadoop.fs.s3a.path.style.access", "true")
        .config(
            "spark.hadoop.fs.s3a.connection.ssl.enabled",
            str(cfg.s3_endpoint.startswith("https:")).lower(),
        )
        .config(
            "spark.hadoop.fs.s3a.aws.credentials.provider",
            "com.amazonaws.auth.EnvironmentVariableCredentialsProvider",
        )
    )
    if os.getenv("SPARK_DRIVER_HOST"):
        builder = builder.config("spark.driver.host", os.environ["SPARK_DRIVER_HOST"]).config(
            "spark.driver.bindAddress", "0.0.0.0"
        )
    if os.path.isdir("/opt/spark-jars"):
        import glob

        builder = builder.config("spark.jars", ",".join(glob.glob("/opt/spark-jars/*.jar")))
    else:
        builder = builder.config("spark.jars.packages", PACKAGES)
    return builder.getOrCreate()


def create_tables(spark):
    for schema in ["bronze", "silver", "gold"]:
        spark.sql(f"CREATE NAMESPACE IF NOT EXISTS lake.{schema}")
    spark.sql("""CREATE TABLE IF NOT EXISTS lake.bronze.kafka_records (
        source_id STRING, topic STRING, kafka_partition INT, kafka_offset BIGINT,
        kafka_timestamp TIMESTAMP, key_base64 STRING, raw_base64 STRING, ingested_at TIMESTAMP)
        USING iceberg PARTITIONED BY (days(kafka_timestamp), topic)
        TBLPROPERTIES ('format-version'='2')""")
    spark.sql("""CREATE TABLE IF NOT EXISTS lake.bronze.dead_letters (
        source_id STRING, topic STRING, kafka_partition INT, kafka_offset BIGINT,
        raw_base64 STRING, reason STRING, ingested_at TIMESTAMP)
        USING iceberg PARTITIONED BY (days(ingested_at))
        TBLPROPERTIES ('format-version'='2')""")
    spark.sql("""CREATE TABLE IF NOT EXISTS lake.silver.telemetry (
        event_id STRING, event_time TIMESTAMP, device_id STRING, voltage DOUBLE,
        power_kw DOUBLE, temperature_c DOUBLE, source_id STRING, ingested_at TIMESTAMP)
        USING iceberg PARTITIONED BY (days(event_time), bucket(8, device_id))
        TBLPROPERTIES ('format-version'='2', 'write.target-file-size-bytes'='134217728')""")
    spark.sql("""CREATE TABLE IF NOT EXISTS lake.silver.market (
        event_id STRING, event_time TIMESTAMP, symbol STRING, price DOUBLE, volume BIGINT,
        source_id STRING, ingested_at TIMESTAMP)
        USING iceberg PARTITIONED BY (days(event_time))
        TBLPROPERTIES ('format-version'='2', 'write.target-file-size-bytes'='134217728')""")
    spark.sql("ALTER TABLE lake.silver.telemetry WRITE ORDERED BY device_id, event_time")
    spark.sql("ALTER TABLE lake.silver.market WRITE ORDERED BY symbol, event_time")


def initialize():
    spark = spark_session()
    create_tables(spark)
    spark.stop()


def merge_insert(spark, frame, table, key):
    frame.createOrReplaceTempView("incoming")
    spark.sql(f"""MERGE INTO {table} t USING incoming s ON t.{key} = s.{key}
        WHEN NOT MATCHED THEN INSERT *""")


def process_batch(batch, batch_id):
    cfg = Settings.from_env()
    spark = batch.sparkSession
    if batch.isEmpty():
        return
    raw = batch.select(
        F.sha2(F.concat_ws(":", "topic", F.col("partition"), F.col("offset")), 256).alias(
            "source_id"
        ),
        "topic",
        F.col("partition").alias("kafka_partition"),
        F.col("offset").alias("kafka_offset"),
        F.col("timestamp").alias("kafka_timestamp"),
        F.base64("key").alias("key_base64"),
        F.base64("value").alias("raw_base64"),
        F.current_timestamp().alias("ingested_at"),
        "value",
    ).cache()
    try:
        # Immutable files first. Retried batches may create duplicate raw files.
        (raw.drop("value").write.mode("append").json(f"s3a://{cfg.bucket}/bronze/raw/kafka"))
        merge_insert(spark, raw.drop("value"), "lake.bronze.kafka_records", "source_id")
        validate = F.udf(validate_payload, "canonical STRING, reason STRING")
        parsed = raw.withColumn("validation", validate("topic", "value")).cache()
        try:
            rejected = parsed.where("validation.reason IS NOT NULL").select(
                "source_id",
                "topic",
                "kafka_partition",
                "kafka_offset",
                "raw_base64",
                F.col("validation.reason").alias("reason"),
                "ingested_at",
            )
            merge_insert(spark, rejected, "lake.bronze.dead_letters", "source_id")
            (
                rejected.select(
                    F.col("source_id").alias("key"), F.to_json(F.struct("*")).alias("value")
                )
                .write.format("kafka")
                .option("kafka.bootstrap.servers", cfg.kafka_bootstrap)
                .option("topic", cfg.dlq_topic)
                .option("kafka.acks", "all")
                .save()
            )
            for topic, kind, fields in [
                (
                    cfg.telemetry_topic,
                    "telemetry",
                    "device_id STRING, voltage DOUBLE, power_kw DOUBLE, temperature_c DOUBLE",
                ),
                (cfg.market_topic, "market", "symbol STRING, price DOUBLE, volume BIGINT"),
            ]:
                schema = T._parse_datatype_string(
                    "event_id STRING, event_time TIMESTAMP, " + fields
                )
                accepted = (
                    parsed.where((F.col("topic") == topic) & F.col("validation.reason").isNull())
                    .withColumn("event", F.from_json("validation.canonical", schema))
                    .select("event.*", "source_id", "ingested_at")
                )
                # Deterministic winner for repeated IDs within a microbatch. Existing IDs
                # are immutable: the first committed value wins across batches.
                window = Window.partitionBy("event_id").orderBy("source_id")
                accepted = (
                    accepted.withColumn("rn", F.row_number().over(window))
                    .where("rn = 1")
                    .drop("rn")
                )
                merge_insert(spark, accepted, f"lake.silver.{kind}", "event_id")
        finally:
            parsed.unpersist()
    finally:
        raw.unpersist()


def run():
    cfg = Settings.from_env()
    spark = spark_session()
    create_tables(spark)
    source = (
        spark.readStream.format("kafka")
        .option("kafka.bootstrap.servers", cfg.kafka_bootstrap)
        .option("subscribe", f"{cfg.telemetry_topic},{cfg.market_topic}")
        .option("startingOffsets", "earliest")
        .option("failOnDataLoss", "true")
        .option("maxOffsetsPerTrigger", os.getenv("MAX_OFFSETS_PER_TRIGGER", "10000"))
        .load()
    )
    query = (
        source.writeStream.foreachBatch(process_batch)
        .option("checkpointLocation", cfg.checkpoint)
        .trigger(processingTime=os.getenv("TRIGGER_INTERVAL", "15 seconds"))
        .start()
    )
    query.awaitTermination()
