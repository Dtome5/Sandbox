"""Great Expectations gates: a failed gate prevents Gold refresh."""

import great_expectations as gx
import pandas as pd

REQUIRED = {
    "telemetry": ["device_id", "voltage", "power_kw", "temperature_c"],
    "market": ["symbol", "price"],
}
RANGES = {
    "telemetry": "voltage < 0 OR voltage > 300 OR power_kw < 0 OR power_kw > 1000 "
    "OR temperature_c < -50 OR temperature_c > 120",
    "market": "price <= 0 OR price > 1000000",
}


def quality_metrics_query(kind: str) -> str:
    if kind not in REQUIRED:
        raise ValueError(f"Unknown quality contract: {kind}")
    null_sql = " OR ".join(f"{column} IS NULL" for column in REQUIRED[kind])
    return f"""SELECT count(*) AS row_count,
        count(*) - count(event_id) AS null_ids,
        count(event_id) - count(DISTINCT event_id) AS duplicate_ids,
        count(*) - count(event_time) AS null_times,
        coalesce(count_if({RANGES[kind]}), 0) AS range_failures,
        coalesce(count_if({null_sql}), 0) AS null_fields
        FROM lake.silver.{kind}"""


def check_frame(frame: pd.DataFrame, kind: str) -> dict:
    if kind not in REQUIRED:
        raise ValueError(f"Unknown quality contract: {kind}")
    context = gx.get_context(mode="ephemeral")
    context.variables.progress_bars = {"globally": False}
    source = context.data_sources.add_pandas(name=f"{kind}_source")
    asset = source.add_dataframe_asset(name=f"{kind}_asset")
    batch = asset.add_batch_definition_whole_dataframe("whole").get_batch(
        batch_parameters={"dataframe": frame}
    )
    expectations = [
        gx.expectations.ExpectColumnValuesToNotBeNull(column="event_id"),
        gx.expectations.ExpectColumnValuesToBeUnique(column="event_id"),
        gx.expectations.ExpectColumnValuesToNotBeNull(column="event_time"),
    ]
    expectations += [
        gx.expectations.ExpectColumnValuesToNotBeNull(column=column) for column in REQUIRED[kind]
    ]
    if kind == "telemetry":
        expectations += [
            gx.expectations.ExpectColumnValuesToBeBetween(
                column="voltage", min_value=0, max_value=300
            ),
            gx.expectations.ExpectColumnValuesToBeBetween(
                column="power_kw", min_value=0, max_value=1000
            ),
            gx.expectations.ExpectColumnValuesToBeBetween(
                column="temperature_c", min_value=-50, max_value=120
            ),
        ]
    elif kind == "market":
        expectations += [
            gx.expectations.ExpectColumnValuesToBeBetween(
                column="price", min_value=0, max_value=1_000_000, strict_min=True
            ),
        ]
    else:
        raise ValueError(f"Unknown quality contract: {kind}")
    results = [batch.validate(expectation).to_json_dict() for expectation in expectations]
    report = {"success": all(r["success"] for r in results), "checks": results}
    if not report["success"]:
        raise ValueError(f"Great Expectations gate failed for {kind}")
    return report
