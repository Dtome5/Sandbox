"""Run aggregate quality gates before the dimensional build; retain evidence in S3."""

import asyncio
import json
import os
import subprocess
from datetime import UTC, datetime
from pathlib import Path
from uuid import uuid4

import boto3
import great_expectations as gx
import pandas as pd
import trino
from prefect import flow, task

from lakehouse.config import Settings
from lakehouse.ingestion.finance import pull_quotes
from lakehouse.quality import quality_metrics_query


@task(retries=2, retry_delay_seconds=10)
def ingest_finance():
    if os.getenv("FINNHUB_TOKEN"):
        asyncio.run(pull_quotes())


@task(retries=2, retry_delay_seconds=10)
def quality_gate():
    conn = trino.dbapi.connect(
        host=os.getenv("TRINO_HOST", "trino"),
        port=8080,
        user="quality",
        catalog="lake",
        schema="silver",
    )
    reports = {}
    try:
        for kind in ["telemetry", "market"]:
            rows = conn.cursor().execute(quality_metrics_query(kind)).fetchone()
            context = gx.get_context(mode="ephemeral")
            context.variables.progress_bars = {"globally": False}
            source = context.data_sources.add_pandas(name="metrics")
            batch = (
                source.add_dataframe_asset(name="metrics")
                .add_batch_definition_whole_dataframe("all")
                .get_batch(
                    batch_parameters={
                        "dataframe": pd.DataFrame(
                            [rows],
                            columns=[
                                "row_count",
                                "null_ids",
                                "duplicate_ids",
                                "null_times",
                                "range_failures",
                                "null_fields",
                            ],
                        )
                    }
                )
            )
            checks = [
                gx.expectations.ExpectColumnValuesToBeBetween(column="row_count", min_value=1)
            ]
            checks += [
                gx.expectations.ExpectColumnValuesToBeBetween(column=c, min_value=0, max_value=0)
                for c in [
                    "null_ids",
                    "duplicate_ids",
                    "null_times",
                    "range_failures",
                    "null_fields",
                ]
            ]
            results = [batch.validate(check).to_json_dict() for check in checks]
            reports[kind] = {"success": all(r["success"] for r in results), "checks": results}
    finally:
        conn.close()
    cfg = Settings.from_env()
    boto3.client("s3", endpoint_url=cfg.s3_endpoint).put_object(
        Bucket=cfg.bucket,
        Key=f"governance/quality/{datetime.now(UTC):%Y/%m/%d}/{uuid4()}.json",
        Body=json.dumps(reports, default=str).encode(),
        ContentType="application/json",
    )
    if not all(report["success"] for report in reports.values()):
        raise ValueError("Silver quality gate failed; inspect governance/quality in object storage")
    return reports


@task
def build_gold():
    root = Path(os.getenv("DBT_PROJECT_DIR", "/app/dbt"))
    try:
        subprocess.run(
            ["dbt", "build", "--project-dir", str(root), "--profiles-dir", str(root)], check=True
        )
    finally:
        cfg = Settings.from_env()
        s3 = boto3.client("s3", endpoint_url=cfg.s3_endpoint)
        prefix = f"governance/dbt/{datetime.now(UTC):%Y%m%dT%H%M%S}-{uuid4()}"
        for name in ["manifest.json", "run_results.json"]:
            artifact = root / "target" / name
            if artifact.exists():
                s3.upload_file(str(artifact), cfg.bucket, f"{prefix}/{name}")


@flow(name="hybrid-lakehouse-gold", log_prints=True)
def refresh_gold():
    ingest_finance()
    quality_gate()
    build_gold()


if __name__ == "__main__":
    refresh_gold.serve(name="quarter-hourly-gold", cron="*/15 * * * *", limit=1)
