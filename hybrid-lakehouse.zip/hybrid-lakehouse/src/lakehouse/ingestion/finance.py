"""Async Finnhub REST quote ingestion; raw response is archived before Kafka delivery."""

import asyncio
import json
import os
from datetime import UTC, datetime
from uuid import NAMESPACE_URL, uuid4, uuid5

import boto3
import httpx

from lakehouse.config import Settings
from lakehouse.contracts import Quote
from lakehouse.ingestion.producer import Publisher


async def fetch_quote(client: httpx.AsyncClient, symbol: str, token: str, attempts: int = 4):
    for attempt in range(attempts):
        try:
            response = await client.get(
                "/api/v1/quote", params={"symbol": symbol}, headers={"X-Finnhub-Token": token}
            )
            if response.status_code == 429 or response.status_code >= 500:
                raise httpx.TransportError(f"transient provider status {response.status_code}")
            # Avoid exceptions containing URLs with secrets or provider response bodies.
            if response.status_code != 200:
                raise ValueError(f"Provider rejected {symbol}: HTTP {response.status_code}")
            return response.json()
        except (httpx.TransportError, ValueError) as error:
            retryable = isinstance(error, httpx.TransportError)
            if not retryable or attempt == attempts - 1:
                raise
            await asyncio.sleep(min(2**attempt, 15))
    raise AssertionError("unreachable")


def normalize_quote(symbol: str, raw: dict) -> Quote:
    timestamp = raw.get("t", 0)
    if not isinstance(timestamp, int | float) or timestamp <= 0:
        raise ValueError("Provider quote has no valid timestamp")
    return Quote(
        schema_version=1,
        event_id=str(uuid5(NAMESPACE_URL, f"finnhub:{symbol}:{timestamp}")),
        event_time=datetime.fromtimestamp(timestamp, UTC),
        symbol=symbol,
        price=raw["c"],
        volume=None,
    )


async def pull_quotes():
    cfg = Settings.from_env()
    token = os.environ["FINNHUB_TOKEN"]
    symbols = [s.strip().upper() for s in os.getenv("SYMBOLS", "AAPL,MSFT,NEE").split(",")]
    s3 = boto3.client("s3", endpoint_url=cfg.s3_endpoint)
    publisher = Publisher(cfg.kafka_bootstrap)
    semaphore = asyncio.Semaphore(3)
    async with httpx.AsyncClient(base_url="https://finnhub.io", timeout=20) as client:

        async def ingest(symbol):
            async with semaphore:
                raw = await fetch_quote(client, symbol, token)
                # Each retrieval is immutable, even when the provider repeats a quote.
                key = f"bronze/provider/finnhub/{datetime.now(UTC):%Y/%m/%d}/{uuid4()}.json"
                await asyncio.to_thread(
                    s3.put_object,
                    Bucket=cfg.bucket,
                    Key=key,
                    Body=json.dumps({"symbol": symbol, "response": raw}).encode(),
                    ContentType="application/json",
                    IfNoneMatch="*",
                )
                event = normalize_quote(symbol, raw)
                publisher.publish(
                    cfg.market_topic, event.model_dump_json().encode(), symbol.encode()
                )

        results = await asyncio.gather(
            *(ingest(symbol) for symbol in symbols), return_exceptions=True
        )
    await asyncio.to_thread(publisher.finish)
    failures = [result for result in results if isinstance(result, BaseException)]
    if failures:
        raise RuntimeError(
            f"{len(failures)} quote pulls failed; raw archives retained"
        ) from failures[0]
