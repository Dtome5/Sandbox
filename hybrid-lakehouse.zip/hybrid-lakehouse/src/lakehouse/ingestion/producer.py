import logging

from confluent_kafka import Producer

from lakehouse.config import Settings
from lakehouse.fixtures import bad_events, sample_events

log = logging.getLogger(__name__)


class Publisher:
    def __init__(self, bootstrap: str):
        self.errors = []
        self.producer = Producer(
            {
                "bootstrap.servers": bootstrap,
                "enable.idempotence": True,
                "acks": "all",
                "delivery.timeout.ms": 120000,
                "compression.type": "lz4",
            }
        )

    def _delivered(self, error, message):
        if error:
            self.errors.append(str(error))

    def publish(self, topic: str, payload: bytes, key: bytes | None = None):
        while True:
            try:
                self.producer.produce(topic, value=payload, key=key, on_delivery=self._delivered)
                self.producer.poll(0)
                return
            except BufferError:
                self.producer.poll(1)

    def finish(self):
        pending = self.producer.flush(120)
        if pending or self.errors:
            raise RuntimeError(
                f"Kafka delivery failed: {pending} pending, {len(self.errors)} errors"
            )


def produce(count: int, include_bad: bool):
    publisher = Publisher(Settings.from_env().kafka_bootstrap)
    events = list(sample_events(count)) + (list(bad_events()) if include_bad else [])
    for topic, payload in events:
        # Device/symbol keys preserve per-entity Kafka ordering.
        import json

        try:
            event = json.loads(payload)
            key = str(event.get("device_id", event.get("symbol", "invalid"))).encode()
        except (ValueError, UnicodeDecodeError):
            key = b"invalid"
        publisher.publish(topic, payload, key)
    publisher.finish()
    log.warning("Published %d records", len(events))
