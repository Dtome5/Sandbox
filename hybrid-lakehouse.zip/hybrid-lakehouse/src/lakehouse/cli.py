import argparse
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description="Hybrid IoT and market lakehouse")
    subs = parser.add_subparsers(dest="command", required=True)
    demo = subs.add_parser("demo", help="Run the offline DuckDB reference pipeline")
    demo.add_argument("--output", type=Path, default=Path("data/demo"))
    producer = subs.add_parser("produce", help="Publish fixtures to Kafka")
    producer.add_argument("--count", type=int, default=240)
    producer.add_argument("--include-bad", action="store_true")
    subs.add_parser("stream", help="Start Kafka → Spark → Iceberg")
    subs.add_parser("init", help="Initialize Iceberg tables")
    subs.add_parser("finance", help="Pull configured Finnhub quotes once")
    subs.add_parser("refresh", help="Run Prefect quality and dbt flow")
    args = parser.parse_args()
    if args.command == "demo":
        from lakehouse.demo import run_demo

        (args.output / "bronze").mkdir(parents=True, exist_ok=True)
        print(json.dumps(run_demo(args.output), indent=2))
    elif args.command == "produce":
        from lakehouse.ingestion.producer import produce

        produce(args.count, args.include_bad)
    elif args.command in {"stream", "init"}:
        from lakehouse.processing.stream import initialize, run

        (initialize if args.command == "init" else run)()
    elif args.command == "finance":
        import asyncio

        from lakehouse.ingestion.finance import pull_quotes

        asyncio.run(pull_quotes())
    elif args.command == "refresh":
        from lakehouse.orchestration.flows import refresh_gold

        refresh_gold()


if __name__ == "__main__":
    main()
