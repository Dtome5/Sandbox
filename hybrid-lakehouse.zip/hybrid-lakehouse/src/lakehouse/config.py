import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Settings:
    kafka_bootstrap: str = "redpanda:9092"
    telemetry_topic: str = "telemetry.v1"
    market_topic: str = "market.quotes.v1"
    dlq_topic: str = "lakehouse.dlq.v1"
    bucket: str = "lakehouse"
    s3_endpoint: str = "http://minio:9000"
    catalog_uri: str = "http://catalog:8181"
    checkpoint: str = "s3a://lakehouse/checkpoints/ingest-v1"

    @classmethod
    def from_env(cls):
        return cls(
            **{key: os.getenv(key.upper(), default) for key, default in cls().__dict__.items()}
        )
