# Distributed Hybrid IoT & Financial Market Intelligence Platform

A runnable reference implementation of a recoverable, distributed lakehouse for inverter
telemetry and financial quotes. It includes a real Kafka-compatible broker, Spark workers,
Iceberg tables, dbt dimensional models, quality gates, orchestration, and BI configuration.

The local deployment is a development environment. AWS Terraform provisions a cloud foundation;
it does **not** deploy a complete production streaming service. See
[production deployment](docs/production.md) and [verification](docs/verification.md) for exact scope.

## Architecture

```mermaid
flowchart LR
  I[Telemetry producer] --> K[Redpanda / Kafka]
  F[Async Finnhub pulls] --> R[Immutable provider responses]
  F --> K
  K --> S[Spark structured streaming]
  S --> B[Bronze raw JSONL + offset index]
  S --> D[Iceberg quarantine + Kafka DLQ]
  S --> V[Silver Iceberg tables]
  V --> Q[Great Expectations gate]
  Q --> T[dbt on Trino]
  T --> G[Gold dimensions / facts / marts]
  G --> BI[Superset]
  G --> ML[SQL / Parquet / ML consumers]
  P[Prefect scheduled flow] --> F
  P --> Q
  P --> T
```

All lake objects live in MinIO locally. Iceberg REST uses a persistent SQLite catalog for the
single-node demo. Spark runs a standalone master and worker; add workers to distribute processing.

## Quick start: no Docker, no API key

Requires Python 3.11 or 3.12 and [uv](https://docs.astral.sh/uv/).

```bash
uv sync --frozen --group dev
uv run lakehouse demo --output data/demo
```

Expected: 304 records captured, 240 telemetry rows and 60 market rows accepted, four malformed
records quarantined. Rerun the command: Silver counts stay the same. Each capture creates a new
immutable raw file. Outputs include a DuckDB database, Gold Parquet files, quality results, and
a summary. This mode tests contracts and replay semantics; it does not replace cluster testing.

```bash
uv run python -c "import duckdb; print(duckdb.connect('data/demo/lakehouse.duckdb').sql('select * from gold.power_hourly').df())"
```

## Distributed local deployment

Requires Docker Compose v2, about 10 GB free disk and 10–12 GB available RAM for the full stack.
The initial image build compiles a checksum-pinned MinIO source release and downloads pinned
Python dependencies and Spark connector JARs. Local
credentials in `.env.example` are illustrative. All published ports bind to loopback.

```bash
cp .env.example .env
docker compose up -d --build
docker compose run --rm producer
# Wait for Spark to consume the seed batch; inspect the stream log if needed.
docker compose logs -f stream
```

In another terminal:

```bash
docker compose exec trino trino --execute 'SELECT count(*) FROM lake.silver.telemetry'
# Once counts are 240 telemetry and 60 market:
docker compose run --rm refresh
docker compose --profile bi up -d --build
```

The BI bootstrap expects the Gold tables to exist. Sign in to Superset at
`http://localhost:8088` as `admin` with `SUPERSET_ADMIN_PASSWORD` from `.env`.
The **Hybrid IoT & Market Intelligence** dashboard connects to actual Gold data through Trino.
If BI starts before Gold exists, build Gold and restart Superset.

| Service | Local URL |
| --- | --- |
| MinIO console | http://localhost:9001 |
| Iceberg REST | http://localhost:8181/v1/config |
| Trino | http://localhost:8080 |
| Spark master | http://localhost:8081 |
| Superset, optional `bi` profile | http://localhost:8088 |
| Prefect, optional `orchestration` profile | http://localhost:4200 |

```bash
# Schedule quality + Gold refresh every 15 minutes, with max one flow at a time.
docker compose --profile orchestration up -d
# Stop services while preserving their named volumes.
docker compose --profile bi --profile orchestration down
```

`FINNHUB_TOKEN` is optional. If set, the refresh flow also requests the configured symbols.
Finnhub quotes include current price and provider timestamp; volume is unavailable and stays
null. REST requests are bounded to three concurrent pulls and retried on transport failures,
429, and 5xx. Entitlements and exchange coverage depend on the provider account.

## Data products

| Layer | Tables / objects | Grain |
| --- | --- | --- |
| Bronze | `bronze/raw/kafka/*.json`, `bronze.kafka_records` | Kafka topic + partition + offset |
| Bronze | `bronze/provider/finnhub/` | One immutable API retrieval |
| Quarantine | `bronze.dead_letters`, `lakehouse.dlq.v1` | Rejected Kafka record |
| Silver | `silver.telemetry` | One accepted telemetry event ID |
| Silver | `silver.market` | One provider quote event ID |
| Gold | `dim_device`, `dim_instrument`, `dim_date` | Kimball conformed dimensions |
| Gold | `fct_power`, `fct_market_quote` | One event / quote |
| Gold | `mart_power_hourly`, `mart_power_rolling` | Hourly and five-minute power summaries |
| Gold | `mart_market_trends` | Twenty-observation moving averages and log-return volatility |

The dimensions are Type 1; SCD Type 2 history is not implemented. Device metadata is enriched
from a seed; unseen devices remain queryable with an `Unmapped` site. Quote volatility is
neither daily nor annualized. Materializations are dbt tables, incremental facts, and staging
views, rather than native Trino materialized views. Marts rebuild from complete fact history
so late arrivals update affected windows correctly.

## Reliability, quality, and optimization

- Versioned JSON schemas and strict extra-field rejection detect incompatible drift. UTC
  timestamps, required fields, finite numeric values, and engineering ranges are validated.
  Voltage limits are the sample inverter contract and should be changed for other grid types.
- Raw binary values and keys are base64 encoded before any parsing. Invalid UTF-8 survives.
- Structured Streaming advances a persisted S3 checkpoint only after the microbatch returns.
  Bronze, quarantine, and Silver use insert-only MERGE keys for safe retries. Kafka DLQ delivery
  is at least once. See [delivery semantics](docs/architecture.md).
- Great Expectations validates full-table aggregate metrics through Trino before dbt runs;
  dbt tests enforce uniqueness, relationships, and value ranges. Evidence is stored under
  `governance/quality/` and `governance/dbt/`.
- Iceberg uses day partitions, device buckets, sort order, and 128 MiB file targets. The
  maintenance script supports metadata-only evolution to hourly partitions and sort compaction.
  **Iceberg is not configured with Z-ordering, and no 60% speedup is claimed.**

```bash
docker compose run --rm init python scripts/benchmark.py --label before --output data/benchmarks.jsonl
docker compose run --rm init python scripts/maintenance.py
docker compose run --rm init python scripts/benchmark.py --label after --output data/benchmarks.jsonl
```

Use a bind-mounted output directory to retain benchmark results from ephemeral containers,
for example `docker compose run --rm -v "$PWD/data:/app/data" init python scripts/benchmark.py ...`.
Benchmark at realistic volume; 300 rows do not establish high-frequency production capacity.

## Tests and CI

```bash
uv sync --frozen --all-extras --group dev
uv run ruff check .
uv run pytest -q
uv run dbt parse --project-dir dbt --profiles-dir dbt
docker compose --env-file .env.example config --quiet
# On a fresh Compose project with empty volumes:
docker compose up -d --build
uv run python scripts/smoke_cluster.py
```

Tests cover malformed bytes, incompatible schemas, future/naive timestamps, invalid numbers,
provider retries, quality rejection, replay deduplication, and a real local Spark Python UDF.
Java 17 is recommended for Spark 3.5. GitHub Actions runs these checks and a cluster job that
restarts the stream, republishes records, and executes `dbt build`, including its unit test.
No cloud credentials are required by CI. Terraform has a separate validation workflow.

For an additional local Iceberg execution check, download the pinned runtime JAR and set
`ICEBERG_RUNTIME_JAR` before running `tests/test_iceberg.py`. This exercises real table DDL,
MERGE replay and partition evolution against a local Hadoop catalog, independently of S3.
The check is skipped when the JAR is absent.

## Cloud foundation and operations

See [production deployment](docs/production.md), [runbook](docs/runbook.md), and
[data architecture](docs/architecture.md). Terraform creates encrypted/versioned S3, a KMS key,
an immutable ECR repository, Glue databases, scoped Spark IAM permissions, and an EMR Serverless
batch application. It does not publish or apply anything automatically.

## Defensible resume statements

- Built a Kafka/Spark/Iceberg lakehouse joining IoT telemetry and financial quotes into dbt
  dimensional models exposed through Trino and Superset.
- Added versioned payload contracts, raw-byte quarantine, replay-safe table writes, automated
  quality gates, and CI checks for Python, Spark, dbt, and Terraform.
- Implemented Iceberg partition evolution and sort compaction with a repeatable query benchmark.
  Add a percentage improvement only after recording baseline and optimized measurements.

Only claim production deployment, throughput, recovery objectives, or measured improvements
after validating them in the target environment. The repository includes the tools to do so.

