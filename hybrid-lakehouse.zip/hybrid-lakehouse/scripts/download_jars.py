"""Resolve the small, fixed Spark connector set at image build time."""

from pathlib import Path
from urllib.request import urlretrieve

ARTIFACTS = [
    ("org.apache.iceberg", "iceberg-spark-runtime-3.5_2.12", "1.7.2"),
    ("org.apache.iceberg", "iceberg-aws-bundle", "1.7.2"),
    ("org.apache.spark", "spark-sql-kafka-0-10_2.12", "3.5.5"),
    ("org.apache.spark", "spark-token-provider-kafka-0-10_2.12", "3.5.5"),
    ("org.apache.kafka", "kafka-clients", "3.4.1"),
    ("org.apache.commons", "commons-pool2", "2.11.1"),
    ("org.apache.hadoop", "hadoop-aws", "3.3.4"),
    ("com.amazonaws", "aws-java-sdk-bundle", "1.12.262"),
]
destination = Path("/opt/spark-jars")
destination.mkdir(parents=True, exist_ok=True)
for group, artifact, version in ARTIFACTS:
    name = f"{artifact}-{version}.jar"
    url = f"https://repo.maven.apache.org/maven2/{group.replace('.', '/')}/{artifact}/{version}/{name}"
    urlretrieve(url, destination / name)
