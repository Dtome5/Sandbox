import time

import boto3
from botocore.exceptions import BotoCoreError, ClientError

from lakehouse.config import Settings

cfg = Settings.from_env()
s3 = boto3.client("s3", endpoint_url=cfg.s3_endpoint)
for attempt in range(60):
    try:
        s3.list_buckets()
        break
    except (BotoCoreError, ClientError):
        if attempt == 59:
            raise
        time.sleep(2)
try:
    s3.head_bucket(Bucket=cfg.bucket)
except ClientError as error:
    if error.response["Error"]["Code"] not in {"404", "NoSuchBucket"}:
        raise
    s3.create_bucket(Bucket=cfg.bucket)
s3.put_bucket_versioning(Bucket=cfg.bucket, VersioningConfiguration={"Status": "Enabled"})
