import time

import httpx

from lakehouse.config import Settings
from lakehouse.processing.stream import initialize

for attempt in range(90):
    try:
        httpx.get(Settings.from_env().catalog_uri + "/v1/config", timeout=3).raise_for_status()
        break
    except httpx.HTTPError:
        if attempt == 89:
            raise
        time.sleep(2)
initialize()
