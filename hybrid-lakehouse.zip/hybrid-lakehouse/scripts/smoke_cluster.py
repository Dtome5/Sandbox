"""End-to-end replay/restart check. Use a fresh Compose project and volumes."""

import subprocess
import time

import trino

COMPOSE = ["docker", "--host=unix:///var/run/docker.sock", "compose"]


def counts():
    conn = trino.dbapi.connect(host="localhost", port=8080, user="smoke", catalog="lake")
    try:
        return {
            table: conn.cursor().execute(f"SELECT count(*) FROM {table}").fetchone()[0]
            for table in [
                "bronze.kafka_records",
                "bronze.dead_letters",
                "silver.telemetry",
                "silver.market",
            ]
        }
    finally:
        conn.close()


def await_counts(expected_bronze):
    deadline = time.monotonic() + 360
    last = None
    while time.monotonic() < deadline:
        try:
            last = counts()
            if last == {
                "bronze.kafka_records": expected_bronze,
                "bronze.dead_letters": expected_bronze // 304 * 4,
                "silver.telemetry": 240,
                "silver.market": 60,
            }:
                print(last)
                return
        except trino.exceptions.TrinoError:
            pass
        time.sleep(3)
    raise AssertionError(f"Timed out waiting for replay convergence: {last}")


subprocess.run(COMPOSE + ["run", "--rm", "producer"], check=True)
await_counts(304)
subprocess.run(COMPOSE + ["restart", "stream"], check=True)
subprocess.run(COMPOSE + ["run", "--rm", "producer"], check=True)
await_counts(608)
subprocess.run(COMPOSE + ["run", "--rm", "refresh"], check=True)
print("Kafka → raw archive → Iceberg → Trino → GX → dbt passed with restart and replay")
