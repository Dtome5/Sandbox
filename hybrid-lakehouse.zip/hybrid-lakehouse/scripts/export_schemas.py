import json
from pathlib import Path

from lakehouse.contracts import TOPIC_MODELS

directory = Path("schemas")
directory.mkdir(exist_ok=True)
for topic, model in TOPIC_MODELS.items():
    (directory / f"{topic}.schema.json").write_text(
        json.dumps(model.model_json_schema(), indent=2) + "\n"
    )
