"""Record repeatable Trino range-query timings; never invent a speedup."""

import argparse
import json
import statistics
import time
from pathlib import Path

import trino

parser = argparse.ArgumentParser()
parser.add_argument("--label", required=True, help="e.g. before-compaction or after-compaction")
parser.add_argument("--host", default="trino")
parser.add_argument("--repeats", type=int, default=7)
parser.add_argument("--output", type=Path, default=Path("data/benchmarks.jsonl"))
args = parser.parse_args()
if args.repeats < 3:
    parser.error("At least three repeats required")
conn = trino.dbapi.connect(host=args.host, port=8080, user="benchmark", catalog="lake")
query = """SELECT count(*), avg(power_kw) FROM silver.telemetry
           WHERE device_id = 'inverter-001'
             AND event_time >= TIMESTAMP '2026-01-05 09:00:00'
             AND event_time < TIMESTAMP '2026-01-05 09:30:00'"""
timings = []
for index in range(args.repeats + 1):
    start = time.perf_counter()
    cursor = conn.cursor()
    result = cursor.execute(query).fetchall()
    elapsed = time.perf_counter() - start
    if index:  # Separate warm-up from reported repetitions.
        timings.append(elapsed)
record = {
    "label": args.label,
    "query": query,
    "repeats": args.repeats,
    "seconds": timings,
    "median_seconds": statistics.median(timings),
    "result": result,
    "last_query_stats": cursor.stats,
}
args.output.parent.mkdir(parents=True, exist_ok=True)
with args.output.open("a") as handle:
    handle.write(json.dumps(record, default=str) + "\n")
print(json.dumps(record, indent=2, default=str))
conn.close()
