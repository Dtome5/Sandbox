"""Run in the app container: python scripts/maintenance.py [--evolve-hourly]."""

import argparse

from lakehouse.processing.stream import spark_session

parser = argparse.ArgumentParser()
parser.add_argument("--evolve-hourly", action="store_true")
args = parser.parse_args()
spark = spark_session()
if args.evolve_hourly:
    # Metadata-only evolution affects future files. Existing day partitions remain readable.
    spark.sql(
        "ALTER TABLE lake.silver.telemetry REPLACE PARTITION FIELD days(event_time) "
        "WITH hours(event_time)"
    )
for table in ["silver.telemetry", "silver.market"]:
    spark.sql(
        f"CALL lake.system.rewrite_data_files(table => '{table}', strategy => 'sort', "
        "options => map('target-file-size-bytes', '134217728'))"
    ).show(truncate=False)
spark.stop()
