{{ config(materialized='incremental', incremental_strategy='merge', unique_key='event_id',
          properties={"format": "'PARQUET'", "partitioning": "ARRAY['day(event_time)']"}) }}
select event_id, event_time, cast(event_time as date) as date_key,
       {{ entity_key('symbol') }} as instrument_key, price, volume, ingested_at
from {{ ref('stg_market') }}
{% if is_incremental() %}
where ingested_at >= (select coalesce(max(ingested_at), timestamp '1970-01-01 00:00:00')
                     - interval '1' hour from {{ this }})
{% endif %}

