select event_id, event_time, device_id, voltage, power_kw, temperature_c, ingested_at
from {{ source('silver', 'telemetry') }}

