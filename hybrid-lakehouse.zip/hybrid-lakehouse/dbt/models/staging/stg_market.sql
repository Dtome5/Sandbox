select event_id, event_time, symbol, price, volume, ingested_at
from {{ source('silver', 'market') }}

