select event_id, device_key, event_time, power_kw,
       avg(power_kw) over (partition by device_key order by event_time
         range between interval '5' minute preceding and current row) as avg_power_kw_5m
from {{ ref('fct_power') }}

