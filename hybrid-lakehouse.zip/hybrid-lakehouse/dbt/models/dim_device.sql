select {{ entity_key('t.device_id') }} as device_key, t.device_id,
       coalesce(m.site_name, 'Unmapped') as site_name,
       coalesce(m.rated_capacity_kw, 0) as rated_capacity_kw
from (select distinct device_id from {{ ref('stg_telemetry') }}) t
left join {{ ref('device_metadata') }} m on t.device_id = m.device_id

