select distinct cast(event_time as date) as date_key,
       year(event_time) as year_number, month(event_time) as month_number,
       day(event_time) as day_number, day_of_week(event_time) as day_of_week_number
from (
  select event_time from {{ ref('stg_telemetry') }}
  union all
  select event_time from {{ ref('stg_market') }}
)

