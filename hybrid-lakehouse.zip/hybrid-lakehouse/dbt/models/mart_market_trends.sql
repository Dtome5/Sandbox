with returns as (
  select q.*, d.symbol,
         ln(price / lag(price) over (partition by q.instrument_key
             order by event_time, event_id)) as log_return
  from {{ ref('fct_market_quote') }} q
  join {{ ref('dim_instrument') }} d on q.instrument_key = d.instrument_key
)
select *, avg(price) over w as moving_avg_20_quotes,
       stddev_samp(log_return) over w as log_return_volatility_20_quotes,
       count(*) over w as observations_in_window
from returns
window w as (partition by instrument_key order by event_time, event_id
             rows between 19 preceding and current row)

