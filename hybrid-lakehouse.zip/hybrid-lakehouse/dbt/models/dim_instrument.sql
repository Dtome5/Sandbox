select {{ entity_key('symbol') }} as instrument_key, symbol,
       'USD' as currency, 'Finnhub or synthetic sample' as source
from (select distinct symbol from {{ ref('stg_market') }})

