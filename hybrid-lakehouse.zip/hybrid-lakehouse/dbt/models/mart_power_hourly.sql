select p.device_key, d.device_id, d.site_name, date_trunc('hour', p.event_time) as hour,
       count(*) as readings, avg(p.power_kw) as avg_power_kw,
       avg(p.voltage) as avg_voltage, max(p.temperature_c) as max_temperature_c
from {{ ref('fct_power') }} p
join {{ ref('dim_device') }} d on p.device_key = d.device_key
group by 1, 2, 3, 4

