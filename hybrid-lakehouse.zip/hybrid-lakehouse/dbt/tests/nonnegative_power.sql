select event_id from {{ ref('fct_power') }}
where power_kw < 0 or power_kw > 1000 or voltage < 0 or voltage > 300

