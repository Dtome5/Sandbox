select event_id from {{ ref('fct_market_quote') }} where price <= 0 or price > 1000000

