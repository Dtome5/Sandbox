{% macro generate_schema_name(custom_schema_name, node) -%}
  {{ custom_schema_name | trim if custom_schema_name else target.schema }}
{%- endmacro %}

{% macro entity_key(column) -%}
  to_hex(md5(to_utf8({{ column }})))
{%- endmacro %}

